package com.example.restaurantfx.models;

import javafx.beans.property.*;

/**
 * Represents a customer order.
 * Uses JavaFX properties for TableView integration.
 */
public class Order {
    private final SimpleIntegerProperty id;
    private final SimpleStringProperty status;
    private final SimpleIntegerProperty totalAmount;
    private final SimpleBooleanProperty paymentDone;

    public Order(int id, String status, int totalAmount, boolean paymentDone) {
        this.id = new SimpleIntegerProperty(id);
        this.status = new SimpleStringProperty(status);
        this.totalAmount = new SimpleIntegerProperty(totalAmount);
        this.paymentDone = new SimpleBooleanProperty(paymentDone);
    }

    public int getId() { return id.get(); }
    public String getStatus() { return status.get(); }
    public int getTotalAmount() { return totalAmount.get(); }
    public boolean isPaymentDone() { return paymentDone.get(); }

    public StringProperty statusProperty() { return status; }
}

