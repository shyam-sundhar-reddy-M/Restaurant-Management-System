package com.example.restaurantfx.models;

import javafx.beans.property.SimpleBooleanProperty;
import javafx.beans.property.SimpleIntegerProperty;

/**
 * Represents a single table in the restaurant.
 * Uses JavaFX properties for TableView integration.
 */
public class RestaurantTable {
    private final SimpleIntegerProperty tableNumber;
    private final SimpleBooleanProperty isReserved;

    public RestaurantTable(int tableNumber, boolean isReserved) {
        this.tableNumber = new SimpleIntegerProperty(tableNumber);
        this.isReserved = new SimpleBooleanProperty(isReserved);
    }

    public int getTableNumber() { return tableNumber.get(); }
    public boolean isIsReserved() { return isReserved.get(); }

    public SimpleIntegerProperty tableNumberProperty() { return tableNumber; }
    public SimpleBooleanProperty isReservedProperty() { return isReserved; }

    @Override
    public String toString() {
        return "Table " + getTableNumber();
    }
}
