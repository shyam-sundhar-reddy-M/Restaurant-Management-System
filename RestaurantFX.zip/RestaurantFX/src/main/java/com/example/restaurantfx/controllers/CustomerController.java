package com.example.restaurantfx.controllers;

import com.example.restaurantfx.db.DatabaseManager;
import com.example.restaurantfx.models.MenuItem;
import com.example.restaurantfx.models.RestaurantTable;
import com.example.restaurantfx.utils.AlertUtil;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class CustomerController {

    // FXML fields for Menu
    @FXML private TableView<MenuItem> menuTable;
    @FXML private TableColumn<MenuItem, String> menuNameColumn;
    @FXML private TableColumn<MenuItem, Integer> menuPriceColumn;

    // FXML fields for Ordering
    @FXML private ListView<MenuItem> currentOrderList;
    @FXML private Label totalAmountLabel;
    @FXML private ComboBox<MenuItem> menuItemsComboBox;
    @FXML private Label orderStatusLabel;

    // FXML fields for Tables
    @FXML private ListView<String> reservedTablesList;
    @FXML private ComboBox<RestaurantTable> availableTablesComboBox;

    private final ObservableList<MenuItem> menuData = FXCollections.observableArrayList();
    private final ObservableList<MenuItem> orderData = FXCollections.observableArrayList();
    private int currentOrderId = -1;
    private int totalAmount = 0;


    @FXML
    public void initialize() {
        menuNameColumn.setCellValueFactory(new PropertyValueFactory<>("name"));
        menuPriceColumn.setCellValueFactory(new PropertyValueFactory<>("price"));

        loadMenuData();
        loadTableData();
        findOrCreateActiveOrder();
        updateOrderStatus();

        menuTable.setItems(menuData);
        menuItemsComboBox.setItems(menuData);
        currentOrderList.setItems(orderData);
    }

    private void loadMenuData() {
        menuData.clear();
        String sql = "SELECT id, name, price FROM menu ORDER BY name";
        // DO NOT use try-with-resources on the Connection object itself.
        Connection conn = DatabaseManager.getConnection();
        if (conn == null) return;

        try (Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                menuData.add(new MenuItem(rs.getInt("id"), rs.getString("name"), rs.getInt("price")));
            }
        } catch (SQLException e) {
            e.printStackTrace();
            AlertUtil.showError("Database Error", "Failed to load menu data: " + e.getMessage());
        }
    }

    private void findOrCreateActiveOrder() {
        String findSql = "SELECT id, total_amount FROM orders WHERE payment_done = FALSE AND status != 'Delivered' LIMIT 1";
        Connection conn = DatabaseManager.getConnection();
        if (conn == null) return;

        try (PreparedStatement findStmt = conn.prepareStatement(findSql)) {
            ResultSet rs = findStmt.executeQuery();
            if (rs.next()) {
                currentOrderId = rs.getInt("id");
                totalAmount = rs.getInt("total_amount");
                loadOrderItems();
            } else {
                String createSql = "INSERT INTO orders (status, total_amount, payment_done) VALUES (?, ?, ?)";
                try (PreparedStatement createStmt = conn.prepareStatement(createSql, Statement.RETURN_GENERATED_KEYS)) {
                    createStmt.setString(1, "No Order");
                    createStmt.setInt(2, 0);
                    createStmt.setBoolean(3, false);
                    int affectedRows = createStmt.executeUpdate();

                    if (affectedRows > 0) {
                        try (ResultSet generatedKeys = createStmt.getGeneratedKeys()) {
                            if (generatedKeys.next()) {
                                currentOrderId = generatedKeys.getInt(1);
                                totalAmount = 0;
                                orderData.clear();
                            }
                        }
                    }
                }
            }
            updateTotalAmountLabel();
        } catch (SQLException e) {
            e.printStackTrace();
            AlertUtil.showError("Database Error", "Failed to find or create an active order: " + e.getMessage());
        }
    }


    @FXML
    private void handleAddItemToOrder() {
        MenuItem selectedItem = menuItemsComboBox.getSelectionModel().getSelectedItem();
        if (selectedItem == null) {
            AlertUtil.showError("No Item Selected", "Please select an item from the dropdown to add.");
            return;
        }
        orderData.add(selectedItem);
        totalAmount += selectedItem.getPrice();
        updateTotalAmountLabel();
        updateOrderStatus("Cooking");
    }

    @FXML
    private void handlePlaceOrder() {
        if (orderData.isEmpty()) {
            AlertUtil.showInfo("Empty Order", "Your order is empty.");
            return;
        }
        if (currentOrderId == -1) {
            AlertUtil.showError("Order Error", "Could not find a valid order ID.");
            return;
        }

        String sql = "UPDATE orders SET total_amount = ?, status = 'Cooking' WHERE id = ?";
        String deleteItemsSql = "DELETE FROM order_items WHERE order_id = ?";
        String insertItemSql = "INSERT INTO order_items (order_id, menu_item_id, quantity, price) VALUES (?, ?, ?, ?)";
        Connection conn = DatabaseManager.getConnection();
        if (conn == null) return;

        try {
            conn.setAutoCommit(false); // Start transaction

            try (PreparedStatement orderStmt = conn.prepareStatement(sql)) {
                orderStmt.setInt(1, totalAmount);
                orderStmt.setInt(2, currentOrderId);
                orderStmt.executeUpdate();
            }

            try (PreparedStatement deleteStmt = conn.prepareStatement(deleteItemsSql)) {
                deleteStmt.setInt(1, currentOrderId);
                deleteStmt.executeUpdate();
            }

            try (PreparedStatement itemStmt = conn.prepareStatement(insertItemSql)) {
                for (MenuItem item : orderData) {
                    itemStmt.setInt(1, currentOrderId);
                    itemStmt.setInt(2, item.getId());
                    itemStmt.setInt(3, 1);
                    itemStmt.setInt(4, item.getPrice());
                    itemStmt.addBatch();
                }
                itemStmt.executeBatch();
            }

            conn.commit();
            AlertUtil.showInfo("Order Placed", "Your order has been successfully placed!");

        } catch (SQLException e) {
            e.printStackTrace();
            try { conn.rollback(); } catch (SQLException ex) { ex.printStackTrace(); }
            AlertUtil.showError("Database Error", "Failed to place the order: " + e.getMessage());
        } finally {
            try { conn.setAutoCommit(true); } catch (SQLException e) { e.printStackTrace(); }
        }
    }

    @FXML
    private void handleMakePayment() {
        if (totalAmount <= 0) {
            AlertUtil.showInfo("No Payment Due", "There is no payment due for the current order.");
            return;
        }
        TextInputDialog dialog = new TextInputDialog(String.valueOf(totalAmount));
        dialog.setTitle("Make Payment");
        dialog.setHeaderText("Total Amount Due: ₹" + totalAmount);
        dialog.setContentText("Enter amount to pay:");

        Optional<String> result = dialog.showAndWait();
        result.ifPresent(amountStr -> {
            try {
                int paidAmount = Integer.parseInt(amountStr);
                if (paidAmount < totalAmount) {
                    AlertUtil.showError("Payment Failed", "Insufficient amount paid.");
                } else {
                    String sql = "UPDATE orders SET payment_done = TRUE, status = 'Ready' WHERE id = ?";
                    Connection conn = DatabaseManager.getConnection();
                    if (conn == null) return;
                    try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                        stmt.setInt(1, currentOrderId);
                        stmt.executeUpdate();

                        int change = paidAmount - totalAmount;
                        AlertUtil.showInfo("Payment Successful", "Thank you. Your change is ₹" + change);

                        resetOrderState();
                    } catch (SQLException e) {
                        e.printStackTrace();
                        AlertUtil.showError("Database Error", "Failed to process payment: " + e.getMessage());
                    }
                }
            } catch (NumberFormatException e) {
                AlertUtil.showError("Invalid Input", "Please enter a valid number.");
            }
        });
    }

    @FXML
    private void handleCancelOrder() {
        if (!AlertUtil.showConfirmation("Cancel Order", "Are you sure you want to cancel the entire current order?")) {
            return;
        }
        Connection conn = DatabaseManager.getConnection();
        if (conn == null) return;

        String sql = "UPDATE orders SET total_amount = 0, status = 'No Order' WHERE id = ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, currentOrderId);
            stmt.executeUpdate();

            String deleteSql = "DELETE FROM order_items WHERE order_id = ?";
            try (PreparedStatement deleteStmt = conn.prepareStatement(deleteSql)) {
                deleteStmt.setInt(1, currentOrderId);
                deleteStmt.executeUpdate();
            }

            AlertUtil.showInfo("Order Cancelled", "Your order has been cancelled.");
            resetOrderState();

        } catch (SQLException e) {
            e.printStackTrace();
            AlertUtil.showError("Database Error", "Failed to cancel the order: " + e.getMessage());
        }
    }

    private void loadOrderItems() {
        orderData.clear();
        String sql = "SELECT m.id, m.name, m.price FROM order_items oi JOIN menu m ON oi.menu_item_id = m.id WHERE oi.order_id = ?";
        Connection conn = DatabaseManager.getConnection();
        if (conn == null) return;

        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, currentOrderId);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                orderData.add(new MenuItem(rs.getInt("id"), rs.getString("name"), rs.getInt("price")));
            }
        } catch (SQLException e) {
            e.printStackTrace();
            AlertUtil.showError("Database Error", "Failed to load order items: " + e.getMessage());
        }
    }

    private void resetOrderState() {
        orderData.clear();
        totalAmount = 0;
        updateTotalAmountLabel();
        findOrCreateActiveOrder();
        updateOrderStatus();
    }

    private void updateTotalAmountLabel() {
        totalAmountLabel.setText("Total: ₹" + totalAmount);
    }

    private void updateOrderStatus(String status) {
        orderStatusLabel.setText("Status: " + status);
    }

    private void updateOrderStatus() {
        if (currentOrderId == -1) return;
        Connection conn = DatabaseManager.getConnection();
        if (conn == null) return;

        String sql = "SELECT status FROM orders WHERE id = ?";
        try(PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, currentOrderId);
            ResultSet rs = stmt.executeQuery();
            if(rs.next()){
                updateOrderStatus(rs.getString("status"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void loadTableData() {
        availableTablesComboBox.getItems().clear();
        reservedTablesList.getItems().clear();

        String sql = "SELECT table_number, is_reserved FROM restaurant_tables ORDER BY table_number";
        List<RestaurantTable> availableTables = new ArrayList<>();
        List<String> reservedTables = new ArrayList<>();
        Connection conn = DatabaseManager.getConnection();
        if (conn == null) return;

        try (Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                int tableNum = rs.getInt("table_number");
                boolean isReserved = rs.getBoolean("is_reserved");
                if (isReserved) {
                    reservedTables.add("Table " + tableNum);
                } else {
                    availableTables.add(new RestaurantTable(tableNum, isReserved));
                }
            }
            availableTablesComboBox.setItems(FXCollections.observableArrayList(availableTables));
            reservedTablesList.setItems(FXCollections.observableArrayList(reservedTables));
        } catch (SQLException e) {
            e.printStackTrace();
            AlertUtil.showError("Database Error", "Failed to load table data: " + e.getMessage());
        }
    }

    @FXML
    private void handleReserveTable() {
        RestaurantTable selectedTable = availableTablesComboBox.getSelectionModel().getSelectedItem();
        if (selectedTable == null) {
            AlertUtil.showError("No Table Selected", "Please select a table to reserve.");
            return;
        }
        Connection conn = DatabaseManager.getConnection();
        if (conn == null) return;

        String sql = "UPDATE restaurant_tables SET is_reserved = TRUE WHERE table_number = ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, selectedTable.getTableNumber());
            int affectedRows = stmt.executeUpdate();
            if (affectedRows > 0) {
                AlertUtil.showInfo("Success", "Table " + selectedTable.getTableNumber() + " reserved successfully.");
                loadTableData();
            }
        } catch (SQLException e) {
            e.printStackTrace();
            AlertUtil.showError("Database Error", "Failed to reserve the table: " + e.getMessage());
        }
    }

    @FXML
    private void handleCancelReservation() {
        String selected = reservedTablesList.getSelectionModel().getSelectedItem();
        if (selected == null) {
            AlertUtil.showError("No Reservation Selected", "Please select a reservation to cancel.");
            return;
        }
        if (!AlertUtil.showConfirmation("Confirm Cancellation", "Are you sure you want to cancel this reservation?")) {
            return;
        }

        try {
            int tableNumber = Integer.parseInt(selected.replace("Table ", ""));
            String sql = "UPDATE restaurant_tables SET is_reserved = FALSE WHERE table_number = ?";
            Connection conn = DatabaseManager.getConnection();
            if (conn == null) return;

            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setInt(1, tableNumber);
                stmt.executeUpdate();
                AlertUtil.showInfo("Success", "Reservation for Table " + tableNumber + " cancelled.");
                loadTableData();
            }
        } catch (NumberFormatException | SQLException e) {
            e.printStackTrace();
            AlertUtil.showError("Error", "Failed to cancel the reservation: " + e.getMessage());
        }
    }
}