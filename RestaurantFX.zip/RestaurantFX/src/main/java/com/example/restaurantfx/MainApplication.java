package com.example.restaurantfx;

import com.example.restaurantfx.db.DatabaseManager;
import com.example.restaurantfx.controllers.MainController;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;

/**
 * The main entry point for the JavaFX application.
 */
public class MainApplication extends Application {
    @Override
    public void start(Stage stage) throws IOException {
        // Load the main view from the FXML file
        FXMLLoader fxmlLoader = new FXMLLoader(MainApplication.class.getResource("/com/example/restaurantfx/main-view.fxml"));
        Scene scene = new Scene(fxmlLoader.load(), 450, 350);
        stage.setTitle("Restaurant Management System");
        stage.setScene(scene);
        stage.setResizable(false);
        stage.show();

        // Ensure the database connection is closed when the application is closed
        stage.setOnCloseRequest(event -> {
            // We consume the event to handle the exit logic in MainController
            event.consume();
            // Get controller and call its exit method
            MainController controller = fxmlLoader.getController();
            controller.handleExit();
        });
    }

    public static void main(String[] args) {
        // Initialize the database connection when the app starts
        DatabaseManager.getConnection();
        launch(args);
    }

    @Override
    public void stop() throws Exception {
        // Close the connection when the app stops
        DatabaseManager.closeConnection();
        super.stop();
    }
}