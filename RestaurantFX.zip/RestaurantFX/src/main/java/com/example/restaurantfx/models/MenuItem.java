package com.example.restaurantfx.models;

import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;

/**
 * Represents a menu item in the restaurant.
 * Uses JavaFX properties to be easily displayed in a TableView.
 */
public class MenuItem {
    private final SimpleIntegerProperty id;
    private final SimpleStringProperty name;
    private final SimpleIntegerProperty price;

    public MenuItem(int id, String name, int price) {
        this.id = new SimpleIntegerProperty(id);
        this.name = new SimpleStringProperty(name);
        this.price = new SimpleIntegerProperty(price);
    }

    public int getId() { return id.get(); }
    public String getName() { return name.get(); }
    public int getPrice() { return price.get(); }

    public void setName(String name) { this.name.set(name); }
    public void setPrice(int price) { this.price.set(price); }

    // This is important for displaying the item name in a ComboBox or ListView
    @Override
    public String toString() {
        return getName() + " - ₹" + getPrice();
    }
}
