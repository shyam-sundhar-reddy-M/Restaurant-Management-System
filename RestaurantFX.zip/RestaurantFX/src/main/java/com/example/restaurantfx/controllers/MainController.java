package com.example.restaurantfx.controllers;

import com.example.restaurantfx.db.DatabaseManager;
import com.example.restaurantfx.utils.AlertUtil;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Modality;
import javafx.stage.Stage;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Controller for the main application window (main-view.fxml).
 * Handles navigation to Customer and Admin panels.
 */
public class MainController {

    private void openPanel(String fxmlFileName, String title) {
        try {
            // Construct the full, correct path based on the project structure
            String fxmlPath = "/com/example/restaurantfx/" + fxmlFileName;
            FXMLLoader loader = new FXMLLoader(getClass().getResource(fxmlPath));
            Parent root = loader.load();
            Stage stage = new Stage();
            stage.initModality(Modality.APPLICATION_MODAL);
            stage.setTitle(title);
            stage.setScene(new Scene(root));
            stage.setResizable(false);
            stage.showAndWait();
        } catch (IOException e) {
            e.printStackTrace(); // This will print the detailed error in your console
            AlertUtil.showError("Error", "Could not open the " + title + " window.");
        }
    }

    @FXML
    private void handleCustomerPanel() {
        openPanel("customer-view.fxml", "Customer Panel");
    }

    @FXML
    private void handleAdminPanel() {
        openPanel("admin-login-view.fxml", "Admin Login");
    }

    @FXML
    public void handleExit() {
        Connection conn = DatabaseManager.getConnection();
        boolean hasReservations = false;
        boolean unpaidOrders = false;

        // Check for reserved tables
        if(conn != null) {
            try (PreparedStatement stmt = conn.prepareStatement("SELECT COUNT(*) FROM restaurant_tables WHERE is_reserved = TRUE");
                 ResultSet rs = stmt.executeQuery()) {
                if (rs.next() && rs.getInt(1) > 0) {
                    hasReservations = true;
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }

            // Check for unpaid orders
            try (PreparedStatement stmt = conn.prepareStatement("SELECT COUNT(*) FROM orders WHERE payment_done = FALSE AND total_amount > 0");
                 ResultSet rs = stmt.executeQuery()) {
                if (rs.next() && rs.getInt(1) > 0) {
                    unpaidOrders = true;
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }


        String message = "Are you sure you want to exit?";
        if (hasReservations || unpaidOrders) {
            String warning = "";
            if (hasReservations) warning += "There are active table reservations.\n";
            if (unpaidOrders) warning += "There are unpaid orders.\n";
            message = warning + "\n" + message;
        }

        if (AlertUtil.showConfirmation("Confirm Exit", message)) {
            Platform.exit();
        }
    }
}
