package com.example.restaurantfx.db;

import com.example.restaurantfx.utils.AlertUtil;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * Manages the connection to the PostgreSQL database.
 * Ensures a single connection instance is used throughout the application.
 */
public class DatabaseManager {
    // --- IMPORTANT ---
    // Update these with your PostgreSQL database details
    private static final String URL = "jdbc:postgresql://localhost:5432/restaurant_db";
    private static final String USER = "postgres"; // <-- CHANGE THIS to your PostgreSQL username
    private static final String PASSWORD = "qwerty@123"; // <-- CHANGE THIS to your PostgreSQL password

    private static Connection connection;

    /**
     * Gets the singleton database connection instance.
     * If the connection does not exist, it creates one.
     * @return The active database connection.
     */
    public static Connection getConnection() {
        if (connection == null) {
            try {
                // Establish the connection
                connection = DriverManager.getConnection(URL, USER, PASSWORD);
                System.out.println("Database connection successful!");
            } catch (SQLException e) {
                System.err.println("Database connection failed!");
                AlertUtil.showError("Database Connection Failed",
                        "Could not connect to the database. Please check your connection settings and ensure the database server is running.");
                e.printStackTrace();
            }
        }
        return connection;
    }

    /**
     * Closes the database connection if it is open.
     */
    public static void closeConnection() {
        if (connection != null) {
            try {
                connection.close();
                connection = null; // Set to null after closing
                System.out.println("Database connection closed.");
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}
