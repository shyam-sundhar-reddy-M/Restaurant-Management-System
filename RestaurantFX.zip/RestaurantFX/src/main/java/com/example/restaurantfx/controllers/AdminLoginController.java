package com.example.restaurantfx.controllers;

/*
 * =========================================================================================
 * File: src/main/java/com/example/restaurantfx/controllers/AdminLoginController.java
 * =========================================================================================
 */

import com.example.restaurantfx.utils.AlertUtil;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.PasswordField;
import javafx.stage.Stage;
import java.io.IOException;

/**
 * Controller for the admin login screen (admin-login-view.fxml).
 */
public class AdminLoginController {
    @FXML
    private PasswordField passwordField;

    private static final String ADMIN_PASSWORD = "BroCode";

    @FXML
    private void handleLogin() {
        String password = passwordField.getText();
        if (ADMIN_PASSWORD.equals(password)) {
            // Close login window
            Stage loginStage = (Stage) passwordField.getScene().getWindow();
            loginStage.close();

            // Open admin panel
            try {
                FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/example/restaurantfx/admin-view.fxml"));
                Parent root = loader.load();
                Stage adminStage = new Stage();
                adminStage.setTitle("Admin Panel");
                adminStage.setScene(new Scene(root));
                adminStage.setResizable(false);
                adminStage.show();
            } catch (IOException e) {
                e.printStackTrace();
                AlertUtil.showError("Error", "Could not load the admin panel.");
            }
        } else {
            AlertUtil.showError("Login Failed", "Incorrect password. Access denied.");
        }
    }
}
