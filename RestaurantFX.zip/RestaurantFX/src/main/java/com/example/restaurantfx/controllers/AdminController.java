package com.example.restaurantfx.controllers;

import com.example.restaurantfx.db.DatabaseManager;
import com.example.restaurantfx.models.MenuItem;
import com.example.restaurantfx.models.Order;
import com.example.restaurantfx.models.RestaurantTable;
import com.example.restaurantfx.utils.AlertUtil;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.control.cell.TextFieldTableCell;
import javafx.util.converter.IntegerStringConverter;

import java.sql.*;
import java.util.Optional;

public class AdminController {

    // Menu Management
    @FXML private TableView<MenuItem> adminMenuTable;
    @FXML private TableColumn<MenuItem, String> adminMenuNameColumn;
    @FXML private TableColumn<MenuItem, Integer> adminMenuPriceColumn;
    @FXML private TextField newItemNameField;
    @FXML private TextField newItemPriceField;

    // Order Tracking
    @FXML private TableView<Order> ordersTable;
    @FXML private TableColumn<Order, Integer> orderIdColumn;
    @FXML private TableColumn<Order, String> orderStatusColumn;
    @FXML private TableColumn<Order, Integer> orderTotalColumn;
    @FXML private TableColumn<Order, Boolean> orderPaymentColumn;

    // Table Reservations
    @FXML private TableView<RestaurantTable> reservationsTable;
    @FXML private TableColumn<RestaurantTable, Integer> tableNumberColumn;
    @FXML private TableColumn<RestaurantTable, Boolean> tableReservedColumn;

    private final ObservableList<MenuItem> menuData = FXCollections.observableArrayList();
    private final ObservableList<Order> orderData = FXCollections.observableArrayList();
    private final ObservableList<RestaurantTable> tableData = FXCollections.observableArrayList();

    @FXML
    public void initialize() {
        setupMenuTable();
        setupOrdersTable();
        setupReservationsTable();

        loadAllData();
    }

    private void loadAllData() {
        loadMenuData();
        loadOrdersData();
        loadReservationsData();
    }

    private void setupMenuTable() {
        adminMenuNameColumn.setCellValueFactory(new PropertyValueFactory<>("name"));
        adminMenuPriceColumn.setCellValueFactory(new PropertyValueFactory<>("price"));

        adminMenuTable.setEditable(true);
        adminMenuNameColumn.setCellFactory(TextFieldTableCell.forTableColumn());
        adminMenuPriceColumn.setCellFactory(TextFieldTableCell.forTableColumn(new IntegerStringConverter()));
    }

    private void loadMenuData() {
        menuData.clear();
        String sql = "SELECT id, name, price FROM menu ORDER BY name";
        Connection conn = DatabaseManager.getConnection();
        if (conn == null) return;

        try (Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                menuData.add(new MenuItem(rs.getInt("id"), rs.getString("name"), rs.getInt("price")));
            }
            adminMenuTable.setItems(menuData);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void handleAddMenuItem() {
        String name = newItemNameField.getText();
        String priceStr = newItemPriceField.getText();
        if (name.isEmpty() || priceStr.isEmpty()) {
            AlertUtil.showError("Invalid Input", "Name and price cannot be empty.");
            return;
        }

        try {
            int price = Integer.parseInt(priceStr);
            String sql = "INSERT INTO menu (name, price) VALUES (?, ?)";
            Connection conn = DatabaseManager.getConnection();
            if (conn == null) return;

            try(PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setString(1, name);
                stmt.setInt(2, price);
                stmt.executeUpdate();

                AlertUtil.showInfo("Success", "Menu item added successfully.");
                newItemNameField.clear();
                newItemPriceField.clear();
                loadMenuData();
            }
        } catch (NumberFormatException e) {
            AlertUtil.showError("Invalid Price", "Please enter a valid number for the price.");
        } catch (SQLException e) {
            AlertUtil.showError("Database Error", "Failed to add menu item. It might already exist.");
            e.printStackTrace();
        }
    }

    @FXML
    private void handleRemoveMenuItem() {
        MenuItem selectedItem = adminMenuTable.getSelectionModel().getSelectedItem();
        if (selectedItem == null) {
            AlertUtil.showError("No Selection", "Please select a menu item to remove.");
            return;
        }

        if (AlertUtil.showConfirmation("Confirm Deletion", "Are you sure you want to remove '" + selectedItem.getName() + "'?")) {
            String sql = "DELETE FROM menu WHERE id = ?";
            Connection conn = DatabaseManager.getConnection();
            if (conn == null) return;

            try(PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setInt(1, selectedItem.getId());
                stmt.executeUpdate();
                loadMenuData();
            } catch (SQLException e) {
                AlertUtil.showError("Database Error", "Failed to remove item. It might be part of an existing order.");
                e.printStackTrace();
            }
        }
    }

    @FXML
    private void onEditMenuName(TableColumn.CellEditEvent<MenuItem, String> event) {
        MenuItem item = event.getRowValue();
        item.setName(event.getNewValue());
        updateMenuItemInDB(item);
    }

    @FXML
    private void onEditMenuPrice(TableColumn.CellEditEvent<MenuItem, Integer> event) {
        MenuItem item = event.getRowValue();
        item.setPrice(event.getNewValue());
        updateMenuItemInDB(item);
    }

    private void updateMenuItemInDB(MenuItem item) {
        String sql = "UPDATE menu SET name = ?, price = ? WHERE id = ?";
        Connection conn = DatabaseManager.getConnection();
        if (conn == null) return;

        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, item.getName());
            stmt.setInt(2, item.getPrice());
            stmt.setInt(3, item.getId());
            stmt.executeUpdate();
        } catch (SQLException e) {
            AlertUtil.showError("Update Failed", "Could not update the item in the database.");
            e.printStackTrace();
            loadMenuData();
        }
    }

    private void setupOrdersTable() {
        orderIdColumn.setCellValueFactory(new PropertyValueFactory<>("id"));
        orderStatusColumn.setCellValueFactory(new PropertyValueFactory<>("status"));
        orderTotalColumn.setCellValueFactory(new PropertyValueFactory<>("totalAmount"));
        orderPaymentColumn.setCellValueFactory(new PropertyValueFactory<>("paymentDone"));
    }

    private void loadOrdersData() {
        orderData.clear();
        String sql = "SELECT id, status, total_amount, payment_done FROM orders ORDER BY created_at DESC";
        Connection conn = DatabaseManager.getConnection();
        if (conn == null) return;

        try (Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                orderData.add(new Order(
                        rs.getInt("id"),
                        rs.getString("status"),
                        rs.getInt("total_amount"),
                        rs.getBoolean("payment_done")
                ));
            }
            ordersTable.setItems(orderData);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void handleUpdateOrderStatus() {
        Order selectedOrder = ordersTable.getSelectionModel().getSelectedItem();
        if (selectedOrder == null) {
            AlertUtil.showError("No Order Selected", "Please select an order to update.");
            return;
        }

        ChoiceDialog<String> dialog = new ChoiceDialog<>(selectedOrder.getStatus(), "Cooking", "Ready", "Delivered");
        dialog.setTitle("Update Order Status");
        dialog.setHeaderText("Update status for Order #" + selectedOrder.getId());
        dialog.setContentText("Choose new status:");

        Optional<String> result = dialog.showAndWait();
        result.ifPresent(newStatus -> {
            String sql = "UPDATE orders SET status = ? WHERE id = ?";
            Connection conn = DatabaseManager.getConnection();
            if (conn == null) return;

            try(PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setString(1, newStatus);
                stmt.setInt(2, selectedOrder.getId());
                stmt.executeUpdate();
                loadOrdersData();
            } catch (SQLException e) {
                AlertUtil.showError("Database Error", "Failed to update order status.");
                e.printStackTrace();
            }
        });
    }

    private void setupReservationsTable() {
        tableNumberColumn.setCellValueFactory(new PropertyValueFactory<>("tableNumber"));
        tableReservedColumn.setCellValueFactory(new PropertyValueFactory<>("isReserved"));
    }

    private void loadReservationsData() {
        tableData.clear();
        String sql = "SELECT table_number, is_reserved FROM restaurant_tables ORDER BY table_number";
        Connection conn = DatabaseManager.getConnection();
        if (conn == null) return;

        try (Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                tableData.add(new RestaurantTable(
                        rs.getInt("table_number"),
                        rs.getBoolean("is_reserved")
                ));
            }
            reservationsTable.setItems(tableData);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void handleRefreshAll() {
        loadAllData();
        AlertUtil.showInfo("Refreshed", "All data has been reloaded from the database.");
    }
}
