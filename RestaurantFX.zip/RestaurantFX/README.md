# RestaurantFX - Restaurant Management System

A desktop application for managing a restaurant, built with JavaFX and backed by a PostgreSQL database. This project was developed as a learning exercise to integrate a graphical user interface with a robust database system.

## Features
- **Customer Panel:** View menu, place orders, make payments, reserve/cancel tables.
- **Admin Panel:** Password protected access to manage the menu, view all orders, and track table reservations.
- **Persistent Data:** All data (menu, orders, tables) is stored in a PostgreSQL database.

## Technologies Used
- Java 24
- JavaFX 21
- PostgreSQL
- JDBC
